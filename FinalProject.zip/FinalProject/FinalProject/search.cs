﻿using System;
namespace FinalProject
{
    public class search
    {

        public class Inventory
        {

            string petName;
            string breed;
            double price;

            public Inventory()
            {
                petName = "xxx";
                breed = " ";
                price = 0.0;
            }

            public Inventory(string c, string d, double p)
            {
                petName = c;
                breed = d;
                price = p;
            }

            public string getName()
            {
                string name = petName;
                return name;
            }

            public string getBreed()
            {
                string d = breed;
                return d;
            }

            public double getAge()
            {
                return price;
            }
        }

        public int currentPosition(Inventory [] array, int size, string value)
        {
            int position = -1;
            int index = 0;
            bool found = false;

            while (index < size && !found)
            {
                if (array[index].getName() == value)
                {
                    found = true;
                    position = index;
                }
                index++;
            }
            return position;
        }

        public void display(Inventory[] array, int size)
        {
            int pos;
            string name;    // Can change to identification number, pet type(dog, cat, etc.), or other form to identify them

            Console.WriteLine("Enter the pet you're looking for");
            name = Convert.ToString(Console.ReadLine());

            pos = currentPosition(array, size, name);
            if (pos == -1)
            {
                Console.WriteLine("The pet is not on the list");
            }
            else
            {
                //Then the pet is found
                Console.WriteLine("This pets breed is ", array[pos].getBreed());
                Console.WriteLine("The pet is ", array[pos].getAge(), " years old");
                Console.WriteLine();
            }
        }
    }
}