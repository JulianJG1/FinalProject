﻿using System;
namespace FinalProject
{
    public class search
    {
        public int currentPosition(String [,] array, int size, string petName)
        {
            int position = -1;
            int index = 0;
            bool found = false;

            while (index < size && !found)
            {
                if (array[index,0] == petName)
                {
                    found = true;
                    position = index;
                }
                index++;
            }
            return position;
        }

        public void display(String[,] array, int size)
        {
            int pos;
            string petName;

            Console.WriteLine("Enter the pet you're looking for");
            petName = Convert.ToString(Console.ReadLine());
            petName = petName.ToLower();
            Console.WriteLine();

            pos = currentPosition(array, size, petName);
            if (pos == -1)
            {
                Console.WriteLine("The pet is not on the list");
                Console.WriteLine();
                display(array, size);
            }
            else
            {
                /*
                string breed = array[pos, 1];
                string age = array[pos, 1];
                string summary = array[pos, 1];
                */

                Console.Write("This pets breed is ");
                Console.WriteLine(array[pos, 1]);
                Console.Write("The pet is ");
                Console.Write(array[pos, 2]);
                Console.WriteLine(" year/s old");
                Console.WriteLine(array[pos, 3]);
                Console.WriteLine(array[pos, 4]);
                Console.WriteLine(array[pos, 5]);
                Console.WriteLine();
            }
        }

        public void loop(String[,] array, int size)
        {
            string doAgain;
            Console.WriteLine("Would you like to continue searching?");
            doAgain = Convert.ToString(Console.ReadLine());
            doAgain = doAgain.ToLower();
            Console.WriteLine();

            if(doAgain == "yes")
            {
                display(array, size);
                loop(array, size);
            }

            else if(doAgain == "no")
            {
                Console.WriteLine("Thank you for choosing Happy Homes");
                Console.WriteLine();
            }

            else if(doAgain != "no" || doAgain != "yes")
            {
                Console.WriteLine("Improper input, please enter \"Yes\", or \"No\"");
                Console.WriteLine();
                loop(array, size);
            }
           
        }

    }
}