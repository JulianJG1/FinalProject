﻿using System;
namespace FinalProject
{
    public class search
    {

       /* public class Pet
        {

            string petName;
            string breed;
            double price;

            public Pet()
            {
                petName = "xxx";
                breed = " ";
                price = 0.0;
            }

            public Pet(string c, string d, double p)
            {
                petName = c;
                breed = d;
                price = p;
            }

            public string getName()
            {
                string name = petName;
                return name;
            }

            public string getBreed()
            {
                string d = breed;
                return d;
            }

            public double getAge()
            {
                return price;
            }
        }*/

        public int currentPosition(String [,] array, int size, string value)
        {
            int position = -1;
            int index = 0;
            bool found = false;

            while (index < size && !found)
            {
                if (array[index,0] == value)
                {
                    found = true;
                    position = index;
                }
                index++;
            }
            return position;
        }

        public void display(String[,] array, int size)
        {
            int pos;
            string name;    // Can change to identification number, pet type(dog, cat, etc.), or other form to identify them

            Console.WriteLine("Enter the pet you're looking for");
            name = Convert.ToString(Console.ReadLine());

            pos = currentPosition(array, size, name);
            if (pos == -1)
            {
                Console.WriteLine("The pet is not on the list");
            }
            else
            {
                //Then the pet is found
                Console.WriteLine("This pets breed is ", array[pos,1]);
                Console.WriteLine("The pet is ", array[pos,2], " year/s old");
                Console.WriteLine();
            }
        }
    }
}