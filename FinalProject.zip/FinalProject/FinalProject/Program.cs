﻿using System;

namespace FinalProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            search findPet = new search();

            int size = 12;   // Can be changed depedning on the amount of pets
            string[,] pets = new string[,] {
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" },
                { "Name1", "Breed1", "1", "Species", "Vaccinated", "Summary" } };

            char doAgain;
            do
            {
                findPet.display(pets, size);     //Search for pet
                
                //Does the user want to shop more?
                Console.WriteLine("Look for more pets?");
                doAgain = Convert.ToChar(Console.ReadLine());
                Console.WriteLine();

            } while (doAgain == 'Y' || doAgain == 'y');
        }
    }
}