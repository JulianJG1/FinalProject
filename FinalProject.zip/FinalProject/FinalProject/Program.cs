﻿using System;

namespace FinalProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            search findPet = new search();

            int size = 6;   // Can be changed depedning on the amount of pets
            string[,] pets = new string[,] { { "Name1", "Breed", "1" }, { "Name2", "Breed", "1" }, { "Name3", "Breed", "1" }, { "Name4", "Breed", "1" }, { "Name5", "Breed", "1" }, { "Name6", "Breed", "1" } };
            //int[] petsID = { 1, 2, 3, 4, 5, 6 };
            char doAgain;
            do
            {
                findPet.display(pets, size);     //Search for pet
                
                //Does the user want to shop more?
                Console.WriteLine("Look for more pets?");
                doAgain = Convert.ToChar(Console.ReadLine());
                Console.WriteLine();

            } while (doAgain == 'Y' || doAgain == 'y');
        }
    }
}