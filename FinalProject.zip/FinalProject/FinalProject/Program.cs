﻿using System;

namespace FinalProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            search findPet = new search();

            int size = 12;   // Can be changed depedning on the amount of pets
            string[,] pets = new string[,] {
                { "name1", "Breed1", "1", "Species", "Up to date on shots", "Summary" },
                { "name2", "Breed1", "2", "Species", "Up to date on shots", "Summary" },
                { "name3", "Breed1", "3", "Species", "Up to date on shots", "Summary" },
                { "name4", "Breed1", "4", "Species", "Up to date on shots", "Summary" },
                { "name5", "Breed1", "5", "Species", "Up to date on shots", "Summary" },
                { "name6", "Breed1", "6", "Species", "Up to date on shots", "Summary" },
                { "name7", "Breed1", "7", "Species", "Up to date on shots", "Summary" },
                { "name8", "Breed1", "8", "Species", "Up to date on shots", "Summary" },
                { "name9", "Breed1", "9", "Species", "Up to date on shots", "Summary" },
                { "name10", "Breed1", "10", "Species", "Up to date on shots", "Summary" },
                { "name11", "Breed1", "11", "Species", "Up to date on shots", "Summary" },
                { "name12", "Breed1", "12", "Species", "Up to date on shots", "Summary" } };

            findPet.display(pets, size);
            findPet.loop(pets, size);
        }
    }
}