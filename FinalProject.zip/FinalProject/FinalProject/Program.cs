﻿using System;

namespace FinalProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            search findItem = new search();

            int size = 6;
            object [] pets =
            {
        ("Name", "Breed", 1),
        ("Name", "Breed", 1),
        ("Name", "Breed", 1),
        ("Name", "Breed", 1),
        ("Name", "Breed", 1),
        ("Name", "Breed", 1),
    };            

            char doAgain;
            do
            {
                findItem.display(pets, size);     //Search for pet
                
                //Does the user want to shop more?
                Console.WriteLine("Look for more items to shop?");
                doAgain = Convert.ToChar(Console.ReadLine());
                Console.WriteLine();

            } while (doAgain == 'Y' || doAgain == 'y');
        }
    }
}